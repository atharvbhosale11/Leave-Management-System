<!DOCTYPE html>
<style>
.TopMenu {
  overflow: hidden;
  background-color: #424242;
}



.TopMenu a:hover {
  background-color: #0277bd;
  color: white;
}



.TopMenu a {
	margin-right: 15px;
  float: right;
  color: #f2f2f2;
  text-align: center;
  padding: 19px 17px;
  text-decoration: none;
  font-size: 17px;
}

.TopMenu h2 {
		
  float: right;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

table {
       border-collapse: collapse;
       width: 100%;
       color: #588c7e;
       font-family: monospace;
       font-size: 25px;
       text-align: left;
         } 
      th {
       background-color: #588c7e;
       color: white;
        }
      tr:nth-child(even) {background-color: #f2f2f2}


</style>
<html>
<title>PICT LMS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="headline">
		<div class="TopMenu">
		<img src="Pict_logo.png" height="60px" width="76px" >

  				<a href="aboutus.html" style="margin-right: 150px;">About-us</a>
  				<a href="contact_us.xml">Contact</a>
  				<a class="active" href="">Home</a>	
  				<H2 style=" text-align:center; margin-top: 4px; margin-right: 1000px; font-size: 22px;"><b>LEAVE &nbsp MANAGEMENT</b></H2>	
		</div>
	</div>


<div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="leftMenu">
  <button onclick="closeLeftMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button>
  <a href="5.html" class="w3-bar-item w3-button">Update profile</a>
  <a href="4.html" class="w3-bar-item w3-button">Apply for leave</a>
  
  <a href="#" class="w3-bar-item w3-button">View Attendance</a>
</div>

<div class="w3-sidebar w3-bar-block w3-card w3-animate-right" style="display:none;right:0;" id="rightMenu">
  <button onclick="closeRightMenu()" class="w3-bar-item w3-button w3-large">Close &times;</button>
  <a href="#" class="w3-bar-item w3-button">Logout</a>
  
</div>

<div class="w3-teal">
  <button class="w3-button w3-teal w3-xlarge w3-left" onclick="openLeftMenu()">&#9776;</button>
  <button class="w3-button w3-teal w3-xlarge w3-right" onclick="openRightMenu()">&#9776;</button>
  <div class="w3-container">
  </div>
</div>
<p style="font-size:30px;">Personal Info :</p>
<table style="width: 100%; margin: 0px; padding: 0px">
     <tr>
      <th>First Name </th> 
      <th>Last name </th> 
      <th>Id </th>
     </tr>
     <?php
    $conn = mysqli_connect("localhost", "root", "", "demo");
      // Check connection
      if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
      } 
      $sql = "SELECT Firstname,Lastname,ID  FROM register";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
       // output data of each row
       while($row = $result->fetch_assoc()) {
        echo "<tr> <td>" . $row["Firstname"]. "</td><td>" . $row["Lastname"] . "</td><td>"
    . $row["ID"]. "</td></tr>";
	 
    }
    echo "</table>";
    } else { echo "0 results"; }
    $conn->close();
    ?>
    </table>


	
	<p style="font-size:30px;">Leave History :</p>
<table style="width: 100%; margin: 0px; padding: 0px">
     <tr>
      
	 <th>ID </th> 
      <th>leave type </th> 
      <th>Reason </th>
	  <th>Status </th>
     </tr>
     <?php
    $conn = mysqli_connect("localhost", "root", "", "demo");
      // Check connection
      if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
      } 
     $sql = "SELECT ID,ltype,Reason,Status   FROM leavehistory";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
       // output data of each row
       while($row = $result->fetch_assoc()) {
        echo "<tr> <td>" . $row["ID"]. "</td><td>" . $row["ltype"] . "</td><td>"
    . $row["Reason"]. "</td><td>" . $row["Status"]. "</td></tr>";
    }
    echo "</table>";
    } else { echo "0 results"; }
    $conn->close();
    ?>
    </table>
<script>
function openLeftMenu() {
  document.getElementById("leftMenu").style.display = "block";
}

function closeLeftMenu() {
  document.getElementById("leftMenu").style.display = "none";
}

function openRightMenu() {
  document.getElementById("rightMenu").style.display = "block";
}

function closeRightMenu() {
  document.getElementById("rightMenu").style.display = "none";
}
</script>
     
</body>
</html>
