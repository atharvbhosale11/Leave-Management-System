<!DOCTYPE html>
<html>
<head>
	<title>LMS | Student</title>

	<style type="text/css">


html{
	background-color: #cccccc;
}

.TopMenu {
	
  overflow: hidden;
  background-color: #424242;
  

}



.TopMenu a:hover {
  background-color: #0277bd;
  color: white;

}



.TopMenu a {
  margin-right: 18px;
  float: right;
  color: #f2f2f2;
 /* padding: 0px;*/
	
  padding: 19px 17px;
  text-decoration: none;
  display: inline-block;
   vertical-align:top;
  font-size: 17px;
  /*position: relative;*/
}

.TopMenu h2 {
		
 
  color: #f2f2f2;
   display: inline-block;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 22px;
}

.abc{
	
	margin-left: 200px;
	width: 250px;
	height: 150px;
	text-align: center;
	margin-top: 20px;
	background-color: white;
	color:black	;
	border-radius: 12px;
	font-size: 20px;

}
* {box-sizing: border-box;
	}


.word-container {
  width: 500px;
  height: 50px;
  margin: 80px auto auto;
  
}
.word-container h1 {
  margin: 0;
  text-align: center;
  color: #ab0a0a;
  
}
.register-container {
  width: 600px;
  margin: 20px auto auto;
  border: 1px solid #000;
  padding: 20px;
  background-color:white;
}


.name label:first-child {
  margin-right: 20px;
  
}
.name label {
  width: calc(100% / 2 - 10px);
  float: left;
}
input, [type="submit"] {
  padding: 8px;
  margin-bottom: 20px;
  width: 100%;
  
}
[type="submit"] {
  border: 1px solid #000000;
  color: #ffffff;
  background-color: #ab0a0a;
  margin: 0;
}
[type="submit"]:hover {
  background-color: red;
}

</style>

	<script>

  function checkPassword(str)
  {
    var re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
    return re.test(str);
  }

  function checkForm(form)
  {
    if(form.fname.value == "" || form.lname.value == "") {
      alert("Error: User name cannot be blank!");
      form.fname.focus();
      return false;
    }
	
	var re = /^[A-Za-z]+$/;
      if(!re.test(form.fname.value))
      {
      alert('First Name must contain only characters');
      return false;
      }
	 var re = /^[A-Za-z]+$/;
      if(!re.test(form.lname.value))
      {
      alert('Last Name must contain only characters');
      return false;
      } 
   /* re = /^\w+$/;
    if(!re.test(form.fname.value)) {
      alert("Error: Firstname must contain only letters, numbers and underscores!");
      form.fname.focus();
      return false;
    }
	*/
    if(form.pwd.value == "") {
	alert("Password fill is blank");
        form.pwd.focus();
        return false;
}
if(form.userid.value == "") {
	alert("ID fill is blank");
        form.pwd.focus();
        return false;
}
if(form.pwd1.value == "") {
	alert("Confirm Password fill is blank");
        form.pwd.focus();
        return false;
}

if(form.pwd.value != form.pwd1.value) {
	alert("Password do not match");
        form.pwd.focus();
        return false;
}

      if(!checkPassword(form.pwd.value)) {
        alert("Error: Password of type:at least one number, one lowercase and one uppercase letter and atleast six letter");
        form.pwd.focus();
        return false;
      }
     
    return true;
  }
function checkForm1(form1)
  {
    if(form1.fname.value == "" || form1.lname.value == "") {
      alert("Error: User name cannot be blank!");
      form1.fname.focus();
      return false;
    }
	
	var re = /^[A-Za-z]+$/;
      if(!re.test(form1.fname.value))
      {
      alert('First Name must contain only characters');
      return false;
      }
	 var re = /^[A-Za-z]+$/;
      if(!re.test(form1.lname.value))
      {
      alert('Last Name must contain only characters');
      return false;
      } 
  
    if(form1.year.value == "") {
	alert("Year fill is blank");
        form1.year.focus();
        return false;
}
if(form1.userid.value == "") {
	alert("ID fill is blank");
        form1.userid.focus();
        return false;
}
if(form1.division.value == "") {
	alert("Confirm Password fill is blank");
        form1.division.focus();
        return false;
}

if(form1.contact.value == "") {
	alert("Contact fill is blank");
        form1.contact.focus();
        return false;
}

     
    return true;
  }
</script>



<meta charset="utf-8">
	<div id="Leave Management" class="tabcontent">
  <h3>Leave Management</h3>
  
</div>
	<link rel="stylesheet" href="css/demo.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 	<link rel="stylesheet"  href="AdminPageCss.css">
 -->	

</head>
<body style="background-color: #cccccc;"> 

		<!-- <p style="font-size:50px;">Leave Management System</p> -->
		
		<div class="TopMenu">
		<img src="Pict_Pune.jpg" height="65px" width="80px" style="float: left;" >
		<span><H2 style=" margin-left: 5px; position: relative;"><b>LEAVE  MANAGEMENT | Student</b></H2></span>
			<a href="about.html" style="margin-right: 150px; ">About-us</a>
  			<a href="contactUs.html">Contact</a>
  			<a class="active" href="">Home</a>	
		</div>



<div class="tab" >
  <button class="tablinks" onclick="openCity(event, 'Dashboard')" id="defaultOpen">Dashboard</button>
   <button class="tablinks" onclick="openCity(event, 'Leave History')">Leave History</button>
  <button class="tablinks" onclick="openCity(event, 'Apply for Leave')">Apply for Leave</button>
  <button class="tablinks" onclick="openCity(event, 'Change Password')">Change Password</button>
  <button class="tablinks" onclick="openCity(event, 'Update')">Update</button>
  <button class="tablinks" onclick="openCity(event, 'Sign Out')">Sign Out</button>
</div>


<div id="Dashboard" class="tabcontent">
<div style="margin-top: 100px">

	<div style="background-color: white; margin-top: 80px; margin-left: 30px;  position: absolute; height: 50%; width: 80%;">
		<h3 style="margin-top: 26px; text-align: center; font-size: 22px; margin-bottom: 30px; ">Latest Leave Applications</h3>

<p style="font-size:30px;">Personal Info :</p>
<table>
     <tr>
      <th>First Name </th> 
      <th>Last name </th> 
      <th>Id </th>
     </tr>
     <?php
    $conn = mysqli_connect("localhost", "root", "ac21", "LMS");
      // Check connection
      if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
      } 
      $sql = "SELECT Firstname,Lastname,ID  FROM student1";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
       // output data of each row
       while($row = $result->fetch_assoc()) {
        echo "<tr> <td>" . $row["Firstname"]. "</td><td>" . $row["Lastname"] . "</td><td>"
    . $row["ID"]. "</td></tr>";
	 
    }
    echo "</table>";
    } else { echo "0 results"; }
    $conn->close();
    ?>
    </table>

<section class="">
  <div class="container">
     <table>
  
        <tr class="header">
          <th>
           ID
            <div>Name</div>
          </th>
          <th>
            Leave Type
            <div>Leave Type</div>
          </th>
           <th>
            Description
            <div>Description</div>
          </th>
         
          <th>
            Status
            <div>Status</div>
          </th>
          
        </tr>
     <?php
    $conn = mysqli_connect("localhost", "root", "", "demo");
      // Check connection
      if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
      } 
     $sql = "SELECT ID,ltype,Reason,Status   FROM leavehistory";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
       // output data of each row
       while($row = $result->fetch_assoc()) {
        echo "<tr> <td>" . $row["ID"]. "</td><td>" . $row["ltype"] . "</td><td>"
    . $row["Reason"]. "</td><td>" . $row["Status"]. "</td></tr>";
    }
    echo "</table>";
    } else { echo "0 results"; }
    $conn->close();
    ?>
      
    </table>
  </div>
</section>
</div>
</div>
</div>

<div id="Apply for Leave" class="tabcontent">
  <div class="word-container">
  <h1>Apply For Leave</h1>
</div>
<div  class="register-container">
  <form >
    
         <label>From :</label><input id="start date" type="date" name="date" placeholder="Enter start date" >
         <label>To :</label><input id="end date" type="date" name="date" placeholder="Enter end date" >
     
		<label>Leave Type :</label>
                  <select id="hint" name="hint" required>
                                    <option value="1">Casual</option>
                                    <option value="2">Medical</option>
                                 	<option value="2">Personal</option>
                                 	<option value="2">Academic</option>
                                    <option value="3">Other</option>
                  </select></br>
   
	  
        <label style=" margin-top: 45px">Description :</label>
      <textarea rows="5" cols="60" id="dol" style="resize:none;" name="dol" placeholder="Add Description about the leave."></textarea>
	   <div class="abc">
	
       <button type="submit"><b>Apply Leave<b></button>
	  </div>
	  
     
  </form>
</div>
</div>


<div id="Leave History" class="tabcontent">
<div style="margin-top: 100px">
	<button class="abc">Total Leaves</button>
	<button class="abc">Approved Leaves</button>
	<button class="abc">Leaves Pending</button></div>

	<div style="background-color: white; margin-top: 80px; margin-left: 30px;  position: absolute; height: 50%; width: 80%;">
		<h3 style="margin-top: 26px; text-align: center; font-size: 22px; margin-bottom: 30px; ">Latest Leave Applications</h3>



<section class="">
  <div class="container">
    <table>
      <thead>
        <tr class="header">
          <th>
            Name
            <div>Name</div>
          </th>
          <th>
            Leave Type
            <div>Leave Type</div>
          </th>
           <th>
            Description
            <div>Description</div>
          </th>
          <th>
            Posting Date
            <div>Posting Date</div>
          </th>
          <th>
            Status
            <div>Status</div>
          </th>
           <th>
            Action
            <div>Action</div>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        <tr>
          <td>Aakash Chavan</td>
          <td>Casual</td>
          <td>I have to go to a seminar.</td>
          <td>21/08/2019</td>
          <td>Pending</td>
          <td>Pending</td>
        </tr>
        


      </tbody>
    </table>
  </div>
</section>
</div>
</div>

<div id="Change Password" class="tabcontent">
<div class="word-container">
  <h1>Change Password</h1>
</div>
<div  class="register-container">
  <form name="form"  action="../stud/update11.php" onsubmit="return checkForm1(this)" method="POST" >
    <div class="name">
      <label>
        <input type="text" placeholder="Enter First Name" name="fname">
      </label>
      <label>
        <input type="text" placeholder="Enter Last Name" name="lname">
      </label>
    </div>
      <label>
        <input type="text" placeholder="Enter UserID" name="userid">
      </label>
	  
	  
      <label>
        <input type="password" placeholder="New Password" name="pwd">
      </label>
	  <label>
        <input type="password" placeholder="Confirm Password" name="pwd1">
      </label>
      
	   <div class="abc">
	  <input type="reset" class="btn btn-secondary" value="Reset" title="Reset">
       <button type="submit" name="signup" value="signup"><b>Save Changes<b></button>
	  </div>
	  
     
  </form>
</div>

</div>

<div id="Update" class="tabcontent">  
<div class="word-container">
  <h1>Update account</h1>
</div>
<div  class="register-container">
  <form name="form1"  action="../stud/update22.php"  onsubmit="return checkForm1(this)" method="POST">
    <div class="name">
      <label>
        <input type="text" placeholder="Enter First Name" name="fname">
      </label>
      <label>
        <input type="text" placeholder="Enter Last Name" name="lname">
      </label>
    </div>
      <label>
        <input type="text" placeholder="Enter UserID" name="userid">
      </label>
	  
	  
      <label>
        <input list="browsers" placeholder="Choose Year" name="year">
         <datalist id="browsers">
    <option value="FE">
    <option value="SE">
    <option value="TE">
    <option value="BE">
    
  </datalist>
      </label>
      	<label>
        <input list="division" placeholder="Choose Division" name="division">
         <datalist id="division">
    <option value="I">
    <option value="II">
    <option value="III">
    <option value="IV">
    
  </datalist>
      </label>
	  <label>
        <input type="text" placeholder="Enter the contact number" name="contact">
      </label>
	   <div class="abc">
	  <input type="reset" class="btn btn-secondary" value="Reset" title="Reset">
       <button type="submit" name="signup" value="signup"><b>Save Changes<b></button>
	  </div>
	  
     
  </form>
</div>
</div>



<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

function validate()
{
	
}
</script>


	

</body>
</html>