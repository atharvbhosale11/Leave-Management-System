<!doctype html>
<html>
<head>
  <title>Register | Student</title>
    <style>
    * {box-sizing: border-box;}
ul {
  background-color: #000000;
}
li a:hover {
  background-color: #0cf72a;
}
.word-container {
  width: 500px;
  height: 50px;
  margin: 80px auto auto;
}
.radio
{
  margin-top: 5%;
    width: 30%;
    margin-left: 35%;
}
h1 {
  margin-top: 5%;
  text-align: center;
  color: #ab0a0a;
}
.register-container {
  width: 600px;
  margin: 20px auto auto;
  border: 1px solid #000;
  padding: 20px;
 background-color:white;
}
label {
  display: block;
}
.name::after {
  content: "";
  display: table;
  clear: both;
}
.name label:first-child {
	margin-right: 20px;
}
.name label {
	width: calc(100% / 2 - 10px);
	float: left;
}
.radio input
{
  margin-left: 20px;
}
.word-container input, [type="submit"] {
  padding: 8px;
  margin-bottom: 20px;
  width: 100%;
}
[type="submit"] {
  border: 1px solid #000000;
  color: #ffffff;
  background-color: #ab0a0a;
  margin: 0;
}
[type="submit"]:hover {
  background-color: red;
}
    </style>
<script>
function validate()
{   
  var fname=document.getElementById("fname").value;
  var lname=document.getElementById("lname").value;
  var contactNo=document.getElementById("contactNo").value;
  var email=document.getElementById("email").value;
  var password=document.getElementById("Password").value;
  var ConfrimPassword=document.getElementById("ConfrimPassword").value;
  var userid=document.getElementById("userid").value;
  var ui=/[C2K]+([0-9])/;
  var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var phoneno = /^\d{10}$/;
    re = /[0-9]/;
    s = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
   var N = /[0-9]/;
   var A = /[A-Z]/;
   var a = /[a-z]/;
   var s = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
  if(fname==null||fname=="") 
  {
    alert("Please first enter Name");
    return false;
  }
  if(N.test(fname) || s.test(fname))
  {
    alert("Name cannot contain number or special characters ");
    return false;
  }
  if(lname==null||lname=="")
  {
    alert("Please enter last Name");
    return false;
  }
  if(N.test(lname) || s.test(lname))
  {
    alert("Name cannot contain number or special characters ");
    return false;
  }
  if(userid==null||userid=="")
  {
    alert("Please enter UserID");
    return false;
  }
  if(ui.test(userid)==false)
  {
    alert("You entered wrong UserID");
    return false;
  }
  if(contactNo==null||contactNo=="")
  {
    alert("Please enter Contact Number");
    return false;
  }
  if(phoneno.test(contactNo)==false)
  {
    alert("You entered wrong contact No");
    return false;
  }
  if(a.test(contactNo) || A.test(contactNo) || s.test(contactNo))
  {
    alert("Contact Number can contain only numbers .");
    return false;
  }
  if (reg.test(email) == false) 
    {
                alert('Invalid Email Address');
                return (false);
    }
    if(email==null||email=="") 
  {
    alert("Please enter email ID");
    return false;
  }
  if(password==null||password=="")
  {
    alert("Please enter password");
    return false;
  }
  else if(password.length<6)
  {
    alert("Password must be atleast 6 characters long");
    return false;
  }
  
  if(!re.test(password))
  {
    alert("Password must contain atleast one number");
    return false;
  }
  if(! /[A-Z]/.test(password))
  {
    alert("Password must contain atleast one capital albhabet");
    return false;
  }
  if(password!=ConfrimPassword)
  {
    alert("Password does not match");
    return false;
  }
}
</script>

</head>

<body>
   <h1>Create your account</h1>
 
  <div class="word-container">
    <h2 style="text-align: center;">Student</h2>
<div class="register-container">
  <form  name="form" onsubmit="return validate()" method="POST">
    <div class="name">
      <label>
        <input type="text" placeholder="First Name" name="fname" id="fname">
      </label>
      <label>
        <input type="text" placeholder="Last Name" name="lname" id="lname">
      </label>
    </div>
	
      <label>
        <input type="text" placeholder="UserID" name="userid" id="userid">
      </label>
       <label>
        <input type="password" placeholder="Password" name="Password" id="Password">
      </label>
    <label>
        <input type="password" placeholder="Re-Password" name="ConfrimPassword" id="ConfrimPassword">
      </label>


      <label>
        <input list="gender" placeholder="Select Gender" name="gender">
         <datalist id="gender">
    <option value="Male">
    <option value="Female">
    <option value="Other">
    </datalist>
      </label>
       <label>
        <input list="Hint Questions" placeholder="Select Hint Question" name="hint" required>
         <datalist id="Hint Questions">
    
                                    <option value="What is your nick name?">
                                    <option value="Which is your favourite song ?">
                                    <option value="What is your favourite color?">
                                    <option value="Who is your best friend ?">
    
  </datalist>
      </label>  
    <label>
        <input type="text" placeholder="Your Answer to Question" name="HintAnswer" id="HintAnswer" required>
      </label>
      <label>
        <input type="text" placeholder="Email ID" name="email" id="email">
      </label>
      <label>
        <input type="Number" placeholder="Contact Number" name="contactNo" id="contactNo">
      </label>
       <label><input type="date" name="date1" placeholder="Enter birthdate" ></label>

       <label>
        <input list="department" placeholder="Choose Department" name="department">
         <datalist id="department">
    <option value="Computer">
    <option value="IT">
    <option value="ENTC">
    </datalist>
      </label>

 
      <label>
        <input list="division" placeholder="Choose Division" name="division">
         <datalist id="division">
    <option value="I">
    <option value="II">
    <option value="III">
    <option value="IV">
    
  </datalist>
      </label>

      <label>
        <input type="number" placeholder="Roll No" name="rollno" id="rollno">
      </label>
      <div class="name">
      <label>
        <input type="submit"  onclick="validate()" name="signup" value="signup">
      </label>
      <label>
        <input type="reset"   name="reset" value="reset">
      </label>
    </div>
     
  </form>
 
</div>

</div>

<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo3') or die("cannot select DB");  

if(isset($_POST["signup"])){  
$fname=$_POST['fname'];

$lname=$_POST['lname'];

$gender=$_POST['gender'];

$id=$_POST['userid'];

$pass=$_POST['Password'];
$hint=$_POST['HintAnswer'];

$email=$_POST['email'];

$contactNo=$_POST['contactNo'];

$date1=$_POST['date1'];

$department=$_POST['department'];

$division=$_POST['division'];


$rno=$_POST['rollno'];


$query= "insert into Student values('$id','$pass','$fname','$lname','$gender','$email','$contactNo','$department','$date1','$division','$rno','$hint')";
 if(mysqli_query($con,$query))
 {
   $message = "You have successfully registered";
	echo "<script type='text/javascript'>alert('$message'); window.history.go(-1);</script>";
 }

 $query1="insert into Login values('$id','$pass')";
 if(mysqli_query($con,$query1))
 {
    

 } 
 header('location: http://localhost/abcd/admin/Home.php');
}


    
?>


</body>
</html>




