<?php
require_once 'db_connect.php';
session_start();

if(isset($_POST['sub_button']))
{
	
	$id=$_POST['username'];
	$pass=$_POST['password'];
	$_SESSION['ID']=$id;
	
	
	$sql= "select id from Login where ((ID= '$id') and (Password ='$pass'))";
	$result = $connect->query($sql);
      if($result->num_rows > 0)
      {
      		if($id[0]=='C')
      {
      		  header('location: http://localhost/abcd/stud/dash2.php');

      }
	  
      else if($id[0]=='T')
	 {		
	 		 header('location: http://localhost/abcd/dash/modi/dash.php');

	 }
	  
      }
	  else if($id=='admin' and $pass=='Admin@21')
	 {		
	 		 header('location: http://localhost/abcd/admin/adminPage.php');

	 }
      else
      {
		 
 $message = "Login Unsuccessful";
	echo "<script type='text/javascript'>alert('$message'); window.history.go(-1);</script>";

      }
 
}


?>

<!DOCTYPE html>
<html>
<head>
<title>LMS</title>

<style>
.login-page {
  width: 20%;
  padding: 8% 0 0;
  margin: auto;
}
.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 360px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #4CAF50;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
}


.TopMenu {
	
  overflow: hidden;
  background-color: #424242;
  

}



.TopMenu a:hover {
  background-color: #0277bd;
  color: white;

}



.TopMenu a {
  margin-right: 18px;
  float: right;
  color: #f2f2f2;
 /* padding: 0px;*/
	
  padding: 19px 17px;
  text-decoration: none;
  display: inline-block;
   vertical-align:top;
  font-size: 17px;
  /*position: relative;*/
}

.TopMenu h2 {
		
 
  color: #f2f2f2;
   display: inline-block;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 22px;
}




</style>
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />
	<link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed-with-address-and-phones.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
</head>
<body>
		<!-- <p style="font-size:50px;">Leave Management System</p> -->
		<div class="headline">
		<div class="TopMenu">

		<img src="Pict_logo.png" height="65px" width="80px" style="float: left;" >
		<span><H2 style=" margin-left: 5px; position: relative;"><b>LEAVE  MANAGEMENT</b></H2></span>
		

  				<a href="about.html" style="margin-right: 150px; ">About-us</a>
  				<a href="contactUs.html">Contact</a>
  				<a class="active" href="">Home</a>	
  					
		</div>
	</div>
			<img src="PICT-Pune.jpg" style='position:fixed;top:0px;left:0px;width:100%;height:100%;z-index:-1;' > 
		<div class="login-page">
		 <h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LOG-IN</h1>
		  <div class="form">
		    
		    <form class="login-form" method="post">
		     <input id="username" type = "text" name="username" placeholder="UserID" required ng-model="uname"><br>
												
		       <input id="password" type = "password" name="password" placeholder="password" required ng-model="pass"><br>
												
		      <button type="submit" name="sub_button">login</button>
			   <button style="margin-top:10px;" type="reset" name="sub_button">Reset</button>
		  <p>   <a href="forgetpassword.php">Forgot Password?</a>&nbsp;Or&nbsp;<a href="register.php">New User?</a> </p>
		    </form>
		  </div>
		</div>
		<footer class="footer-distributed">

					<div class="footer-left">
		                <figure>
						<img src="Pict_logo.png" style='height:100px;'>
		               </figure>
						<p class="footer-links">
							
							
							<a href="about.html">About</a>
							·
							
							
							<a href="contactUs.html">Contact</a>
						</p>
						

						
					</div>

					<div class="footer-center">

						<div>
						
							<i class="fa fa-map-marker"></i>
							<details>
						
		  <p><span>Survey No. 27, Near Trimurti Chowk, Dhankawadi, Pune, Maharashtra 411043</span> Pune, India</p>
		</details>
						</div>

						<div>
							<i class="fa fa-phone"></i>
							<p>+91 24371101</p>
						</div>

						<div>
							<i class="fa fa-envelope"></i>
							<p><a href="mailto:www.pict.edu">principal@pict.edu</a></p>
						</div>

					</div>

					<div class="footer-right">

						<p class="footer-company-about">
							<span>Working Hours</span>
							Working days:Monday to Friday<br>
		                    Working Time:<time>10:00am</time> to <time>5:00pm</time>                 

						</p>

					

					</div>

				</footer>

</body>
</html>