<?php
        require_once 'db_connect.php';
        session_start();

        ?>

<!DOCTYPE html>
<html>
<head>
	<title>LMS | Admin</title>

	<style type="text/css">


html{
	background-color: #cccccc;
}

.TopMenu {
	
  overflow: hidden;
  background-color: #424242;
  

}



.TopMenu a:hover {
  background-color: #0277bd;
  color: white;

}



.TopMenu a {
  margin-right: 18px;
  float: right;
  color: #f2f2f2;
 /* padding: 0px;*/
	
  padding: 19px 17px;
  text-decoration: none;
  display: inline-block;
   vertical-align:top;
  font-size: 17px;
  /*position: relative;*/
}

.TopMenu h2 {
		
 
  color: #f2f2f2;
   display: inline-block;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 22px;
}

.abc{
	
	margin-left: 200px;
	width: 250px;
	height: 150px;
	text-align: center;
	background-color: white;
	color:black	;
	border-radius: 12px;
	font-size: 20px;

}


</style>
<meta charset="utf-8">
	<!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
	<!-- <meta name="keywords" content="footer, address, phone, icons" /> -->
	<link rel="stylesheet" href="css/demo.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="AdminPageCss.css">
	<!-- <link rel="stylesheet" href="css/footer-distributed-with-address-and-phones.css"> -->
	<!-- <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css"> -->
</head>
<body style="background-color: #cccccc;"> 

		<!-- <p style="font-size:50px;">Leave Management System</p> -->
		
		<div class="TopMenu">
		<img src="Pict_logo.png" height="65px" width="80px" style="float: left;" >
		<span><H2 style=" margin-left: 5px; position: relative;"><b>LEAVE  MANAGEMENT | ADMIN</b></H2></span>
		<a  href="logout.php" style="margin-right: 20px;"> Logout</a>
			<a href="aboutus.html" style="margin-right: 40px; ">About-us</a>
  			<a href="contact_us.xml">Contact</a>
  			<a class="active" href="">Home</a>	
				
		</div>



<div class="tab" >
  <button class="tablinks" onclick="openCity(event, 'Dashboard')" id="defaultOpen">Dashboard</button>
  <button class="tablinks" onclick="openCity(event, 'Approved Leaves')">Approved Leaves</button>
  <button class="tablinks" onclick="openCity(event, 'Pending Leaves')">Pending Leaves</button>
  <button class="tablinks" onclick="openCity(event, 'Rejected Leaves')">Rejected Leaves</button>
  
</div>

<div id="Dashboard" class="tabcontent">
<div style="margin-top: 100px">
	<button class="abc">Total Leaves : <?php 
	$sql = "select count(ID) as count from Admin";
	$result = $connect->query($sql);
	
	if($result)
	{
		
		#$count = mysql_fetch_object($result->count);
		while($row = mysqli_fetch_assoc($result))
		{
			echo $row['count'];
		}

	}
	else
	{
		echo "Error";
	}


	   ?>    </button>

	<button class="abc">Approved Leaves : 

			<?php 
	$sql = "select count(ID) as count from Admin where Action='Approved'";
	$result = $connect->query($sql);
	
	if($result)
	{
		
		#$count = mysql_fetch_object($result->count);
		while($row = mysqli_fetch_assoc($result))
		{
			echo $row['count'];
		}

	}
	else
	{
		echo "Error";
	}


	   ?>


	</button>
	<button class="abc">Leaves Pending : 


			<?php 
	$sql = "select count(ID) as count from Admin where Action='Pending'";
	$result = $connect->query($sql);
	
	if($result)
	{
		
		#$count = mysql_fetch_object($result->count);
		while($row = mysqli_fetch_assoc($result))
		{
			echo $row['count'];
		}

	}
	else
	{
		echo "Error";
	}


	   ?>


	</button></div>

	<div style="background-color: white; margin-top: 80px; margin-left: 30px;  position: absolute;  width: 80%;">
		<h3 style="margin-top: 26px; text-align: center; font-size: 22px; margin-bottom: 30px; ">Latest Leave Applications</h3>



<section class="">
  <div class="container" style="max-height: 350px;" >
  	<form action="" method="post">
    <table>
      <thead>
        <tr class="header">
          <th>
            ID
            <div>ID</div>
          </th>
          <th>
            Leave Type
            <div>Leave Type</div>
          </th>
           <th>
            Description
            <div>Description</div>
          </th>
          <th>
            Posting Date
            <div>Posting Date</div>
          </th>
          <th>
            Status
            <div>Status</div>
          </th>
           <th>
            Action
            <div>Action</div>
          </th>
        </tr>
      </thead>
      <tbody>
         
        <?php

        $sql = "select a.ID,Action,s.PostingDate,LeaveType,Description from Admin a,StudentWhichApply s where a.ID = s.ID and a.postingdate=s.PostingDate union select a.ID,Action,t.PostingDate,LeaveType,Description from Admin a,TeacherWhichApply t where a.ID = t.ID and a.postingdate = t.PostingDate order by PostingDate DESC 
";
        $result = $connect->query($sql);
        if ($result) {
        	
        	while($row=mysqli_fetch_array($result))
        	{
        		$ID=$row['ID'];
        		$LeaveType=$row['LeaveType'];
        		$Description=$row['Description'];
        		$Postdate=$row['PostingDate'];
				$Postdate5=$row['PostingDate'];
        		$Status=$row['Action'];
				
				$temp = explode(" ",$Postdate);
				$Postdate = $temp[0].$temp[1];
				
        		

        		echo ' 
        			<tr>
        				<td>'.$ID.'</td>
        				<td>'.$LeaveType.'</td>
        				<td>'.$Description.'</td>
        				<td>'.$Postdate5	.'</td>
        				<td>'.$Status.'</td>
        				<td>
        				<div class="custom-select">
							  <select name="dropdown_'.$ID.'_'.$Postdate.'">
							  <option value="">Select Options</option>
							    <option value="Pending">Pending</option>
							    <option value="Approved">Approved</option>
							    <option value="Rejected">Rejected</option>							    
							  </select>
							  <button type="submit" name="Submit_'.$ID.'_'.$Postdate.'" value="Confirm">Confirm</button>
							 

						</div>
						</td>
						</tr>

        		';

        	}
        	echo '</table></form></div></section>';

    //     	if(isset($_POST['submitbut'])){
				// $selected_val = $_POST['dropdown']; 
				// //echo $selected_val;

    //     		$sql1 = "update AdminTest set Status='$selected_val' where Name='$Name'";
    //     		$result1 = $connect->query($sql1);
    //     		if($result1)
    //     		{
        				
    //     		}
    //     		else
    //     		{
    //     			echo "Errrrrorr";
    //     		}


    //     }

        	$sql = " select a.ID,Action,s.PostingDate,Action,LeaveType,Description from Admin a,StudentWhichApply s where a.ID = s.ID and a.postingdate = s.PostingDate  union  select a.ID,Action,t.PostingDate,Action,LeaveType,Description from Admin a,TeacherWhichApply t where a.ID = t.ID and a.postingdate = t.PostingDate order by PostingDate DESC";
        	$result = $connect->query($sql);
		    while($row = mysqli_fetch_array($result))
		    {		
									
				
		        $id = $row['ID'];
				$Postdate3 = $row["PostingDate"];
				$Postdate1 = $row["PostingDate"];
				$temp1 = explode(" ",$Postdate1);
				$Postdate1 = $temp1[0].$temp1[1];
				
				
					
		        if(isset($_POST["Submit_".$id."_".$Postdate1]))
		        {	
		        	$selected_val = $_POST['dropdown_'.$id.'_'.$Postdate1];
					
		        	if($selected_val=='Pending' || $selected_val=='Approved' || $selected_val=='Rejected')
		        	{	
											
						
		        		$sql1 = "update admin set Action='$selected_val' where ID='$id' and postingdate='$Postdate3'";
						
		         		$result1 = $connect->query($sql1);
		         		if($result1)
		         		{
		        			//echo "Success!!!";
							
							

		         		}
		         		else
		         		{
		         			echo "Error : Please select correct value !!";
		         		}
		         	}
		        }

		    }



        	// $selected_val = $_POST['dropdown'];
        	// if($selected_val=='Pending1' || $selected_val=='Approved2' || $selected_val=='Rejected3')
        	// {
        	// 	$sql1 = "update AdminTest set Status='$selected_val' where Name='$find'";
         // 		$result1 = $connect->query($sql1);
         // 		if($result1)
         // 		{
        				
         // 		}
         // 		else
         // 		{
         // 			echo "Errrrrorr";
         // 		}



        	// }


        	


    }
        else
        {
        	echo "Eror";
        }



        ?>


      </tbody>
    </table>
  </div>
</section>






	</div>

</div>

<div id="Approved Leaves" class="tabcontent">
  


<div style="background-color: white; margin-top: 80px; margin-left: 30px;  position: absolute;  width: 80%;">
		<h3 style="margin-top: 26px; text-align: center; font-size: 22px; margin-bottom: 30px; ">Approved Applications</h3>



<section class="">
  <div class="container" style="max-height: 350px;">
    <table>
      <thead>
        <tr class="header">
          <th>
            ID
            <div>ID</div>
          </th>
          <th>
            Leave Type
            <div>Leave Type</div>
          </th>
           <th>
            Description
            <div>Description</div>
          </th>
          <th>
            Posting Date
            <div>Posting Date</div>
          </th>
          <th>
            Status
            <div>Status</div>
          </th>
           
        </tr>
      </thead>
      <tbody>
        
        				
        
        <?php

        $sql = " select s.ID,Action,s.PostingDate,LeaveType,Description from Admin a,StudentWhichApply s where Action='Approved' and a.postingdate=s.PostingDate union  select t.ID,Action,t.PostingDate,LeaveType,Description from Admin a,TeacherWhichApply t where  Action='Approved' and a.postingdate=t.PostingDate";
        $result = $connect->query($sql);
        if ($result) {
        	
        	while($row=mysqli_fetch_array($result))
        	{
        		$ID=$row['ID'];
        		$LeaveType=$row['LeaveType'];
        		$Description=$row['Description'];
        		$Postdate=$row['PostingDate'];
        		$Status=$row['Action'];
        		

        		echo ' 
        			<tr>
        				<td>'.$ID.'</td>
        				<td>'.$LeaveType.'</td>
        				<td>'.$Description.'</td>
        				<td>'.$Postdate.'</td>
        				<td>'.$Status.'</td>
        				


        		';


        	}
        }
        else
        {
        	echo "Eror";
        }



        ?>


      </tbody>
    </table>
  </div>
</section>

</div>

  	

</div>

<div id="Pending Leaves" class="tabcontent">
  





<div style="background-color: white; margin-top: 80px; margin-left: 30px;  position: absolute;  width: 80%;">
		<h3 style="margin-top: 26px; text-align: center; font-size: 22px; margin-bottom: 30px; ">Pending Applications</h3>



<section class="">
  <div class="container" style="max-height: 350px;">
    <table>
      <thead>
        <tr class="header">
          <th>
            ID
            <div>ID</div>
          </th>
          <th>
            Leave Type
            <div>Leave Type</div>
          </th>
           <th>
            Description
            <div>Description</div>
          </th>
          <th>
            Posting Date
            <div>Posting Date</div>
          </th>
          <th>
            Status
            <div>Status</div>
          </th>
           
        </tr>
      </thead>
      <tbody>
        
        				
        
        <?php

        $sql = "select a.ID,Action,s.PostingDate,LeaveType,Description from Admin a,StudentWhichApply s where  Action='Pending' and a.postingdate=s.PostingDate   union  select a.ID,Action,t.PostingDate,LeaveType,Description from Admin a,TeacherWhichApply t where  Action='Pending' and a.postingdate=t.PostingDate";
        $result = $connect->query($sql);
        if ($result) {
        	
        	while($row=mysqli_fetch_array($result))
        	{
        		$ID=$row['ID'];
        		$LeaveType=$row['LeaveType'];
        		$Description=$row['Description'];
        		$Postdate=$row['PostingDate'];
        		$Status=$row['Action'];
        		

        		echo ' 
        			<tr>
        				<td>'.$ID.'</td>
        				<td>'.$LeaveType.'</td>
        				<td>'.$Description.'</td>
        				<td>'.$Postdate.'</td>
        				<td>'.$Status.'</td>
        				


        		';


        	}
        }
        else
        {
        	echo "Eror";
        }



        ?>


      </tbody>
    </table>
  </div>
</section>

</div>

  	

</div>
  	

</div>

<div id="Rejected Leaves" class="tabcontent">
  




<div style="background-color: white; margin-top: 80px; margin-left: 30px;  position: absolute;  width: 80%;">
		<h3 style="margin-top: 26px; text-align: center; font-size: 22px; margin-bottom: 30px; ">Rejected Applications</h3>



<section class="">
  <div class="container" style="max-height: 350px;">
    <table>
      <thead>
        <tr class="header">
          <th>
            ID
            <div>ID</div>
          </th>
          <th>
            Leave Type
            <div>Leave Type</div>
          </th>
           <th>
            Description
            <div>Description</div>
          </th>
          <th>
            Posting Date
            <div>Posting Date</div>
          </th>
          <th>
            Status
            <div>Status</div>
          </th>
           
        </tr>
      </thead>
      <tbody>
        
        				
        
        <?php

        $sql = "select a.ID,Action,s.PostingDate,LeaveType,Description from Admin a,StudentWhichApply s where  Action='Rejected' and a.postingdate=s.PostingDate   union  select a.ID,Action,t.PostingDate,LeaveType,Description from Admin a,TeacherWhichApply t where  Action='Rejected' and a.postingdate=t.PostingDate";
        $result = $connect->query($sql);
        if ($result) {
        	
        	while($row=mysqli_fetch_array($result))
        	{
        		$ID=$row['ID'];
        		$LeaveType=$row['LeaveType'];
        		$Description=$row['Description'];
        		$Postdate=$row['PostingDate'];
        		$Status=$row['Action'];
        		

        		echo ' 
        			<tr>
        				<td>'.$ID.'</td>
        				<td>'.$LeaveType.'</td>
        				<td>'.$Description.'</td>
        				<td>'.$Postdate.'</td>
        				<td>'.$Status.'</td>
        				


        		';


        	}
        }
        else
        {
        	echo "Eror";
        }



        ?>


      </tbody>
    </table>
  </div>
</section>

</div>

  	

</div>





  	

</div>



<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>


	

</body>
</html>