

<!doctype html>
<html>
<head>

    <style>

.TopMenu {
	
  overflow: hidden;
  background-color: #424242;
  

}



.TopMenu a:hover {
  background-color: #0277bd;
  color: white;

}



.TopMenu a {
  margin-right: 18px;
  float: right;
  color: #f2f2f2;
 /* padding: 0px;*/
	
  padding: 19px 17px;
  text-decoration: none;
  display: inline-block;
   vertical-align:top;
  font-size: 17px;
  /*position: relative;*/
}

.TopMenu h2 {
		
 
  color: #f2f2f2;
   display: inline-block;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 22px;
}
    * {box-sizing: border-box;}
ul {
  background-color: #000000;
}
li a:hover {
  background-color: #0cf72a;
}
.word-container {
  width: 500px;
  height: 50px;
  margin: 80px auto auto;
}
.radio
{
  margin-top: 5%;
    width: 30%;
    margin-left: 35%;
}
h1 {
  margin-top: 5%;
  text-align: center;
  color: #ab0a0a;
}
.register-container {
  width: 600px;
  margin: 20px auto auto;
  border: 1px solid #000;
  padding: 20px;
  background-color:white;
}
label {
  display: block;
}
.name::after {
  content: "";
  display: table;
  clear: both;
}
.name label:first-child {
	margin-right: 20px;
}
.name label {
	width: calc(100% / 2 - 10px);
	float: left;
}
.radio input
{
  margin-left: 20px;
}
.word-container input, [type="submit"] {
  padding: 8px;
  margin-bottom: 20px;
  width: 100%;
}
[type="submit"] {
  border: 1px solid #000000;
  color: #ffffff;
  background-color: #ab0a0a;
  margin: 0;
}
[type="submit"]:hover {
  background-color: red;
}
    </style>
    <script>


  function checkForm(form)
  {
    if(form.UserID.value =="") {
	alert("UserID fill is blank");
        return false;
}
if(form.Answer.value == "") {
	alert("Answer fill is blank");
        form.pwd.focus();
        return false;
}
if(form.pwd.value == "" ||form.ConfirmPwd.value == "") {
	alert("Password fill is blank");
        form.pwd.focus();
        return false;
}
if(form.pwd.value != form.ConfirmPwd.value) {
	alert("Password not match");
        form.pwd.focus();
        return false;
}

    return true;
  }
  
</script>
</head>

<body style="background-color: #cccccc;">

<div class="headline">
		<div class="TopMenu">

		<img src="Pict_logo.png" height="65px" width="80px" style="float: left;" >
		<span><H2 style=" margin-left: 5px; position: relative;"><b>LEAVE  MANAGEMENT</b></H2></span>
		

  				<a href="about.html" style="margin-right: 150px; ">About-us</a>
  				<a href="contactUs.html">Contact</a>
  				<a href="Home.php">Home</a>	
  					
		</div>
	</div>
   <h1>Forgot Password</h1>

  <div class="word-container">
  
<div class="register-container">
  <form name="form"  onsubmit="return checkForm(this)" action="../admin/forgetpass.php" method="POST">
   
      <label>
        <input type="text" placeholder="UserID" name="UserID">
   	  </label>
   	   <label>
        <input list="Hint Questions" placeholder="Select Hint Question" name="hint">
         <datalist id="Hint Questions">
    
                                    <option value="What is your nick name?">
                                    <option value="Which is your favourite song ?">
                                    <option value="What is your favourite color?">
                                    <option value="Who is your best friend ?">
    
  </datalist>
      </label>  
	  <label>
        <input type="text" placeholder="Your Answer to Question" name="Answer">
      </label>
      
       <label>
        <input type="password" placeholder="Password" name="pwd">
      </label>
      <label>
        <input type="password" placeholder="Re-Password" name="ConfirmPwd">
      </label>
       <div class="name">
      <label>
        <input type="submit" name="signup" onclick="return checkForm(this)" value="Change Password">
      </label>
      <label>
        <input type="reset"   name="reset" value="Reset" >
      </label>
    </div>
      
  </form>
</div>
</div>
</body>
</html>


