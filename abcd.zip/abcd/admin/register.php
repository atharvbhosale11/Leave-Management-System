<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<style type="text/css">
		p{
			text-align: center;

		}
		iframe{
			margin-left: 20%;
		}
		.TopMenu {
	
  overflow: hidden;
  background-color: #424242;
  

}



.TopMenu a:hover {
  background-color: #0277bd;
  color: white;

}



.TopMenu a {
  margin-right: 18px;
  float: right;
  color: #f2f2f2;
 /* padding: 0px;*/
	
  padding: 19px 17px;
  text-decoration: none;
  display: inline-block;
   vertical-align:top;
  font-size: 17px;
  /*position: relative;*/
}

.TopMenu h2 {
		
 
  color: #f2f2f2;
   display: inline-block;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 22px;
}
		
	</style>
</head>
<body style="background-color: #cccccc;">

<div class="headline">
		<div class="TopMenu">

		<img src="Pict_logo.png" height="65px" width="80px" style="float: left;" >
		<span><H2 style=" margin-left: 5px; position: relative;"><b>LEAVE  MANAGEMENT</b></H2></span>
			<a href="about.html" style="margin-right: 40px; ">About-us</a>
  			<a href="contactUs.html">Contact</a>
  			<a class="active" href="Home.php">Home</a>
  					
		</div>
	</div>
<center>

 <h3><a href="Home.php">Already Registered ?</a></h3>
<p><a href="regStudent.php" target="iframe_a"><h1>Student</h1></a></p>
<p><a href="rTeac.php" target="iframe_a"><h1>Teacher</h1></a></p>
</center>
<iframe height="1050px"  width="60%" src="regStudent.php" name="iframe_a"></iframe>



</body>
</html>
