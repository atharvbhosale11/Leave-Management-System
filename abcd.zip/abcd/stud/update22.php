<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo') or die("cannot select DB");  

if(isset($_POST["signup"])){  
$fname=$_POST['fname'];

$design=$_POST['year'];
$id=$_POST['userid'];
$pass=$_POST['division'];
$cpass=$_POST['contact'];

$query= "update student set Year= '$design', Division= '$pass',contactNo='$cpass',ID='$id' where FirstName = '$fname'";
 if(mysqli_query($con,$query))
 {
	 echo "<h3>successfully changed</h3>";
 }
}
  

    
?>