 <?php
	 
    require_once 'db_connect.php';
	session_start();
	 $ID1 = $_SESSION['ID'];
	 
	 $_SESSION['ID']=$ID1;
	 
   
    ?>


<!DOCTYPE html>
<html>
<head>
	<title>LMS | Student</title>

	<style type="text/css">


html{
	background-color: #cccccc;
}



.abc{
	
	margin-left: 200px;
	width: 250px;
	height: 150px;
	text-align: center;
	margin-top: 20px;
	background-color: white;
	color:black	;
	border-radius: 12px;
	font-size: 20px;

}
* {box-sizing: border-box;
	}


.word-container {
  width: 500px;
  height: 50px;
  margin: 80px auto auto;
  
}
.word-container h1 {
  margin: 0;
  text-align: center;
  color: #ab0a0a;
  
}
.register-container {
  width: 600px;
  margin: 20px auto auto;
  border: 1px solid #000;
  padding: 20px;
  background-color:white;
}


.name label:first-child {
  margin-right: 20px;
  
}
.name label {
  width: calc(100% / 2 - 10px);
  float: left;
}
input, [type="submit"] {
  padding: 8px;
  margin-bottom: 20px;
  width: 100%;
  
}
[type="submit"] {
  border: 1px solid #000000;
  color: #ffffff;
  background-color: #ab0a0a;
  margin: 0;
}
[type="submit"]:hover {
  background-color: red;
}



.TopMenu {
	
  overflow: hidden;
  background-color: #424242;
  

}



.TopMenu a:hover {
  background-color: #0277bd;
  color: white;

}



.TopMenu a {
  margin-right: 18px;
  float: right;
  color: #f2f2f2;
 /* padding: 0px;*/
	
  padding: 19px 17px;
  text-decoration: none;
  display: inline-block;
   vertical-align:top;
  font-size: 17px;
  /*position: relative;*/
}

.TopMenu h2 {
		
 
  color: #f2f2f2;
   display: inline-block;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 22px;
}


</style>

	<script>

  function checkPassword(str)
  {
    var re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
    return re.test(str);
  }

  function checkForm(form)
  {
    
	

   /* re = /^\w+$/;
    if(!re.test(form.fname.value)) {
      alert("Error: Firstname must contain only letters, numbers and underscores!");
      form.fname.focus();
      return false;
    }
	*/
    if(form.year.value == "") {
	alert("Year fill is blank");
        form.year.focus();
        return false;
}
if(form.division.value == "") {
	alert("Division fill is blank");
        form.division.focus();
        return false;
}
if(form.contact.value == "") {
	alert("Contact fill is blank");
        form.contact.focus();
        return false;
}


    return true;
  }
function checkForm1(form1)
  {
    if(form1.pwd.value == "" || form1.pwd1.value == "") {
      alert("Error: Password cannot be blank!");
      form1.pwd.focus();
      return false;
    }
	
	

     
    return true;
  }
  
 function checkForm2(form2)
  {
    if(form2.date1.value == "" || form2.date2.value == "") {
      alert("Error: Starting or ending Date is missing!");
      form2.date1.focus();
      return false;
    }
	
if(form2.date1.value > form2.date2.value ) {
      alert("Error: Invalid Input Date!");
      form2.date1.focus();
      return false;
    }
  
    if(form2.hint.value == "") {
	alert("Leave type not entered");
        form2.hint.focus();
        return false;
}
if(form2.dol.value == "") {
	alert("Description not entered");
        form2.dol.focus();
        return false;
}

     
    return true;
  } 
</script>



<meta charset="utf-8">
	<div id="Leave Management" class="tabcontent">
  <h3>Leave Management</h3>
  
</div>
	<link rel="stylesheet" href="css/demo.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="AdminPageCss.css">
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body style="background-color: #cccccc;"> 

		<!-- <p style="font-size:50px;">Leave Management System</p> -->
		
		<div class="headline">
		<div class="TopMenu">

		<img src="Pict_logo.png" height="65px" width="80px" style="float: left;" >
		<span><H2 style=" margin-left: 5px; position: relative;"><b>LEAVE  MANAGEMENT</b></H2></span>
		
	<a  href="logout.php" style="margin-right: 20px;"> Logout</a>
			<a href="about.html" style="margin-right: 40px; ">About-us</a>
  			<a href="contactUs.html">Contact</a>
  			<a class="active" href="dash2.php">Home</a>
  					
		</div>
	</div>



<div class="tab" >
  <button class="tablinks" onclick="openCity(event, 'Dashboard')" id="defaultOpen">Dashboard</button>
   
  <button class="tablinks" onclick="openCity(event, 'Apply for Leave')">Apply for Leave</button>
  <button class="tablinks" onclick="openCity(event, 'Change Password')">Change Password</button>
  <button class="tablinks" onclick="openCity(event, 'Update')">Update</button>
  
</div>


<div id="Dashboard" class="tabcontent">
<div style="margin-top: 100px">

	<div style="background-color: white; margin-top: 80px; margin-left: 30px;  position: absolute;  width: 80%;">
		<h3 style="margin-top: 26px; text-align: center; font-size: 22px; margin-bottom: 30px; ">History</h3>

<p style="font-size:30px;">Personal Info :</p>
<table>
     <tr>
      <th>First Name </th> 
      <th>Last name </th> 
      <th>Id </th>
     </tr>
     <?php
	 
    $conn = mysqli_connect("localhost", "root", "", "demo3");
      // Check connection
      if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
      } 
	  
	  
      $sql = "SELECT FirstName,LastName,ID FROM student where ID='$ID1'";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
       // output data of each row
       while($row = $result->fetch_assoc()) {
        echo "<tr> <td>" . $row["FirstName"]. "</td><td>" . $row["LastName"] . "</td><td>"
    . $row["ID"]. "</td></tr>";
	 
    }
    echo "</table>";
    } else {  }
   
    ?>
    </table>

<section class="">
  <div class="container" style="max-height: 350px;">
     <table>
  
        <tr class="header">
          <th>
           ID
            <div>ID</div>
          </th>
          <th>
            Leave Type
            <div>Leave Type</div>
          </th>
           <th>
            Description
            <div>Description</div>
          </th>
         
          <th>
            Status
            <div>Status</div>
          </th>
          
        </tr>
     <?php
   $conn = mysqli_connect("localhost", "root", "", "demo3");
      // Check connection
      if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
      } 
     $sql = "SELECT s.ID,s.LeaveType,s.Description,a.Action from admin a,studentwhichapply s where a.ID=s.ID and a.ID='$ID1' and a.postingdate=s.PostingDate";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
       // output data of each row
       while($row = $result->fetch_assoc()) {
        echo "<tr> <td>" . $row["ID"]. "</td><td>" . $row["LeaveType"] . "</td><td>"
    . $row["Description"]. "</td><td>" . $row["Action"]. "</td></tr>";
    }
    echo "</table>";
    } else {  }
    $conn->close();
    ?>
      
    </table>
  </div>
</section>
</div>
</div>
</div>

<div id="Apply for Leave" class="tabcontent">
  <div class="word-container">
  <h1>Apply For Leave</h1>
</div>
<div  class="register-container">
  <form name="form2"  onsubmit="return checkForm2(this)"  action="../stud/updateleave.php"  method="POST" >
    
         <label>From :</label><input id="start date" type="date" name="date1" placeholder="Enter start date" >
         <label>To :</label><input id="end date" type="date" name="date2" placeholder="Enter end date" >
     
		<label>Leave Type :</label>
                  <select id="hint" name="hint" required>
                                    <option value="Casual">Casual</option>
                                    <option value="Medical">Medical</option>
                                 	<option value="Personal">Personal</option>
                                 	<option value="Academic">Academic</option>
                                    <option value="Other">Other</option>
                  </select></br>
   
	  
        <label>Description :</label>
      <textarea rows="5" cols="60" id="dol" style="resize:none; margin-top: 30px;" name="dol" placeholder="Add Description about the leave."></textarea>
	   <div class="abc">
	
       <button type="submit" name="signup" value="signup"><b>Apply Leave<b></button>
	  </div>
	  
     
  </form>
</div>
</div>




<div id="Change Password" class="tabcontent">
<div class="word-container">
  <h1>Change Password</h1>
</div>
<div  class="register-container">
  <form name="form1"  action="../stud/update111.php" onsubmit="return checkForm1(this)" method="POST" >
  
     
	  
	  
      <label>
        <input type="password" placeholder="New Password" name="pwd">
      </label>
	  <label>
        <input type="password" placeholder="Confirm Password" name="pwd1">
      </label>
      
	   <div class="abc">
	  <input type="reset" class="btn btn-secondary" value="Reset" title="Reset">
       <button type="submit" name="signup" value="signup"><b>Save Changes<b></button>
	  </div>
	  
     
  </form>
</div>

</div>

<div id="Update" class="tabcontent">
<div class="word-container">
  <h1>Update account</h1>
</div>
<div  class="register-container">
  <form name="form"  action="../stud/update222.php"  onsubmit="return checkForm(this)" method="POST">
    
	  
	  
      <label>
        <input list="browsers" placeholder="Choose Year" name="year">
         <datalist id="browsers">
    <option value="FE">
    <option value="SE">
    <option value="TE">
    <option value="BE">
    
  </datalist>
      </label>
      	<label>
        <input list="division" placeholder="Choose Division" name="division">
         <datalist id="division">
    <option value="I">
    <option value="II">
    <option value="III">
    <option value="IV">
    
  </datalist>
      </label>
	  <label>
        <input type="text" placeholder="Enter the contact number" name="contact">
      </label>
	   <div class="abc">
	  <input type="reset" class="btn btn-secondary" value="Reset" title="Reset">
       <button type="submit" name="signup1" value="signup1"><b>Save Changes<b></button>
	  </div>
	  
     
  </form>
</div>
</div>



<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

function validate()
{
	
}
</script>


	

</body>
</html>