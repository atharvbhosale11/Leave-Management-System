<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo3') or die("cannot select DB");  

if(isset($_POST["signup"])){  
$fname=$_POST['fname'];
$id=$_POST['userid'];
$pass=$_POST['pwd'];


$query= "update student set  Password= '$pass',ID='$id' where FirstName = '$fname'";
 if(mysqli_query($con,$query))
 {
	 echo "<h3>successfully changed</h3>";
 }
}
  

    
?>