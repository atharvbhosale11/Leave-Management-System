<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo') or die("cannot select DB");  

if(isset($_POST["signup"])){  
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$design=$_POST['design'];
$id=$_POST['userid'];
$pass=$_POST['pwd'];
$cpass=$_POST['pwd1'];

$query= "update register set Dseignation= '$design', password= '$pass',confirmpassword='$cpass',ID='$id' where Firstname = '$fname'";
 if(mysqli_query($con,$query))
 {
	 echo "<h3>successfully changed</h3>";
 }
}
  

    
?>