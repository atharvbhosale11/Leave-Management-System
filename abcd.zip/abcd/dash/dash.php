<!DOCTYPE html>
<html>
<head>
	<title>LMS | Admin</title>

	<style type="text/css">


html{
	background-color: #cccccc;
}

.TopMenu {
	
  overflow: hidden;
  background-color: #424242;
  

}



.TopMenu a:hover {
  background-color: #0277bd;
  color: white;

}



.TopMenu a {
  margin-right: 18px;
  float: right;
  color: #f2f2f2;
 /* padding: 0px;*/
	
  padding: 19px 17px;
  text-decoration: none;
  display: inline-block;
   vertical-align:top;
  font-size: 17px;
  /*position: relative;*/
}

.TopMenu h2 {
		
 
  color: #f2f2f2;
   display: inline-block;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 22px;
}

.abc{
	
	margin-left: 200px;
	width: 250px;
	height: 150px;
	text-align: center;
	background-color: white;
	color:black	;
	border-radius: 12px;
	font-size: 20px;

}


</style>
<meta charset="utf-8">
	
	<link rel="stylesheet" href="css/demo.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="AdminPageCss.css">
	
</head>
<body style="background-color: #cccccc;"> 

		<!-- <p style="font-size:50px;">Leave Management System</p> -->
		
		<div class="TopMenu">
		<img src="Pict_logo.png" height="65px" width="80px" style="float: left;" >
		<span><H2 style=" margin-left: 5px; position: relative;"><b>LEAVE  MANAGEMENT | ADMIN</b></H2></span>
			<a href="aboutus.html" style="margin-right: 150px; ">About-us</a>
  			<a href="contact_us.xml">Contact</a>
  			<a class="active" href="">Home</a>	
		</div>



<div class="tab" >
  <button class="tablinks" onclick="openCity(event, 'Dashboard')" id="defaultOpen">Dashboard</button>
 
  <button class="tablinks" onclick="openCity(event, 'Leave Management')">Apply for Leave</button>
  <button class="tablinks" ><a href="update.php">Change Password</a></button>
  <button class="tablinks" onclick="openCity(event, 'Update data')">Update the data</button>
  <button class="tablinks" onclick="openCity(event, 'Sign Out')">Sign Out</button>
</div>

<div id="Dashboard" class="tabcontent">
<div style="margin-top: 100px">
	
	<p style="font-size:30px;">Personal Info :</p>
<table>
     <tr>
      <th>First Name </th> 
      <th>Last name </th> 
      <th>Id </th>
     </tr>
     <?php
    $conn = mysqli_connect("localhost", "root", "", "demo");
      // Check connection
      if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
      } 
      $sql = "SELECT Firstname,Lastname,ID  FROM register";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
       // output data of each row
       while($row = $result->fetch_assoc()) {
        echo "<tr> <td>" . $row["Firstname"]. "</td><td>" . $row["Lastname"] . "</td><td>"
    . $row["ID"]. "</td></tr>";
	 
    }
    echo "</table>";
    } else { echo "0 results"; }
    $conn->close();
    ?>
    </table>

	<div style="background-color: white; margin-top: 80px; margin-left: 30px;  position: absolute; height: 50%; width: 80%;">
		<h3 style="margin-top: 26px; text-align: center; font-size: 50px; margin-bottom: 30px; ">Leave History</h3>



<section class="">
  <div class="container">
    <table>
  
        <tr class="header">
          <th>
           ID
            <div>Name</div>
          </th>
          <th>
            Leave Type
            <div>Leave Type</div>
          </th>
           <th>
            Description
            <div>Description</div>
          </th>
         
          <th>
            Status
            <div>Status</div>
          </th>
          
        </tr>
     <?php
    $conn = mysqli_connect("localhost", "root", "", "demo");
      // Check connection
      if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
      } 
     $sql = "SELECT ID,ltype,Reason,Status   FROM leavehistory";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
       // output data of each row
       while($row = $result->fetch_assoc()) {
        echo "<tr> <td>" . $row["ID"]. "</td><td>" . $row["ltype"] . "</td><td>"
    . $row["Reason"]. "</td><td>" . $row["Status"]. "</td></tr>";
    }
    echo "</table>";
    } else { echo "0 results"; }
    $conn->close();
    ?>
      
    </table>
  </div>
</section>







<!-- <table cellspacing="0" cellpadding="0" border="1"  width="325" id="customers">
<tr>
  <td>
   <table cellspacing="0" cellpadding="1" border="1" width="100%" >
     <tr style="color:white; font-weight: bold; background-color:grey;">
        <th>Name</th>
        <th>Leave Type</th>
        <th>Date</th>
        <th>Status</th>
        <th>Action</th>
     </tr>
   </table>
  </td>
</tr>
<tr>
 <td>
   <div style="width:100%; height:70%; overflow:auto;">
     <table cellspacing="0" cellpadding="1" border="1" width="100%" >
       <tr>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         
       </tr>
       <tr>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         
       </tr>
       <tr>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         
       </tr>
       <tr>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         <td>new item</td>
         
       </tr>   
     </table>  
   </div>
  </td>
 </tr>
</table> -->



<!-- <table id="customers" >
  <tr>
    <th>Company</th>
    <th>Contact</th>
    <th>Country</th>
  </tr>
  <tr>
    <td>Alfreds Futterkiste</td>
    <td>Maria Anders</td>
    <td>Germany</td>
  </tr>
  <tr>
    <td>Berglunds snabbköp</td>
    <td>Christina Berglund</td>
    <td>Sweden</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
  <tr>
    <td>Ernst Handel</td>
    <td>Roland Mendel</td>
    <td>Austria</td>
  </tr>
  <tr>
    <td>Island Trading</td>
    <td>Helen Bennett</td>
    <td>UK</td>
  </tr>
  <tr>
    <td>Königlich Essen</td>
    <td>Philip Cramer</td>
    <td>Germany</td>
  </tr>
  <tr>
    <td>Laughing Bacchus Winecellars</td>
    <td>Yoshi Tannamuri</td>
    <td>Canada</td>
  </tr>
  <tr>
    <td>Magazzini Alimentari Riuniti</td>
    <td>Giovanni Rovelli</td>
    <td>Italy</td>
  </tr>
  <tr>
    <td>North/South</td>
    <td>Simon Crowther</td>
    <td>UK</td>
  </tr>
  <tr>
    <td>Paris spécialités</td>
    <td>Marie Bertrand</td>
    <td>France</td>
  </tr>
</table> -->


	</div>

</div>

<div id="Leave Management" class="tabcontent">
  <h3>Leave Management</h3>
  <p>Paris is the capital of France.</p> 
</div>

<div id="Sign Out" class="tabcontent">
  <h3>Sign Out</h3>
  <p>Tokyo is the capital of Japan.</p>
</div>

<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>


	

</body>
</html>