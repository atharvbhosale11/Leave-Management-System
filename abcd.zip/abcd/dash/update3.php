<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo2') or die("cannot select DB");  

if(isset($_POST["signup"])){  
$fname=$_POST['date1'];
$lname=$_POST['date2'];
$design=$_POST['hint'];
$id=$_POST['dol'];


$query= "INSERT INTO teacherwhichapply (FromDate,ToDate,LeaveType,Description)
VALUES ('$fname', '$lname', '$design', '$id')";
 if(mysqli_query($con,$query))
 {
	 echo "<h3>successfully changed</h3>";
 }
}
  

    
?>