<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo3') or die("cannot select DB");  


if(isset($_POST["signup"])){  

$pass=$_POST['pwd'];
$ID2=$_POST['UserID'];

$query= "update teacher set Password= '$pass' where ID = '$ID2'";
 if(mysqli_query($con,$query))
 {
	
	 echo "<h3>Password successfully changed</h3>";
		
 }
 $query1= "update login set Password= '$pass' where ID = '$ID2'";
 if(mysqli_query($con,$query1))
 {
	
		 echo "<h3>Password successfully changed</h3>";
 }
}
  

    
?>