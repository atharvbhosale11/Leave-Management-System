

<!doctype html>
<html>
<head>

    <style>
    * {box-sizing: border-box;}
ul {
  background-color: #000000;
}
li a:hover {
  background-color: #0cf72a;
}
.word-container {
  width: 500px;
  height: 50px;
  margin: 80px auto auto;
}
.radio
{
  margin-top: 5%;
    width: 30%;
    margin-left: 35%;
}
h1 {
  margin-top: 5%;
  text-align: center;
  color: #ab0a0a;
}
.register-container {
  width: 600px;
  margin: 20px auto auto;
  border: 1px solid #000;
  padding: 20px;
 
}
label {
  display: block;
}
.name::after {
  content: "";
  display: table;
  clear: both;
}
.name label:first-child {
	margin-right: 20px;
}
.name label {
	width: calc(100% / 2 - 10px);
	float: left;
}
.radio input
{
  margin-left: 20px;
}
.word-container input, [type="submit"] {
  padding: 8px;
  margin-bottom: 20px;
  width: 100%;
}
[type="submit"] {
  border: 1px solid #000000;
  color: #ffffff;
  background-color: #ab0a0a;
  margin: 0;
}
[type="submit"]:hover {
  background-color: red;
}
    </style>
    <script>

  
</script>
</head>

<body>
   <h1>Forgot Password</h1>

  <div class="word-container">
  
<div class="register-container">
  <form action="../dash/modi/forgetpass.php" method="POST">
   
      <label>
        <input type="text" placeholder="UserID" name="UserID">
   	  </label>
   	   <label>
        <input list="Hint Questions" placeholder="Select Hint Question" name="hint">
         <datalist id="Hint Questions">
    
                                    <option value="What is your nick name?">
                                    <option value="Which is your favourite song ?">
                                    <option value="What is your favourite color?">
                                    <option value="Who is your best friend ?">
    
  </datalist>
      </label>  
	  <label>
        <input type="text" placeholder="Your Answer to Question" name="Answer">
      </label>
      
       <label>
        <input type="password" placeholder="Password" name="pwd">
      </label>
      <label>
        <input type="password" placeholder="Re-Password" name="ConfirmPwd">
      </label>
      
      <button type="submit" name="signup" value="signup"><b>Change Password<b></button>
  </form>
</div>
</body>
</html>


