<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo3') or die("cannot select DB");  

session_start();
	 $ID2 = $_SESSION['ID'];

if(isset($_POST["signup"])){  

$pass=$_POST['pwd'];


$query= "update teacher set Password= '$pass' where ID = '$ID2'";
 if(mysqli_query($con,$query))
 {
	header('location: http://localhost/abcd/dash/modi/dash.php');
		
 }
 $query1= "update login set Password= '$pass' where ID = '$ID2'";
 if(mysqli_query($con,$query1))
 {
	header('location: http://localhost/abcd/dash/modi/dash.php');
		
 }
}
  

    
?>