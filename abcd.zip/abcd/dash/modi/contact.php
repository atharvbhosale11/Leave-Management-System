<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo3') or die("cannot select DB");  
session_start();
	 $ID2 = $_SESSION['ID'];

if(isset($_POST["signup"])){  
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$message=$_POST['message'];



$query= "INSERT INTO contact (FirstName,LastName,Email,Message)
VALUES ('$fname', '$lname', '$email', '$message')";


 if(mysqli_query($con,$query))
 {
	header('location: http://localhost/abcd/dash/modi/dash.php');
 }


}
  

    
?>