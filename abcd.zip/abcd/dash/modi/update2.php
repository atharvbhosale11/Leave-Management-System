<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo3') or die("cannot select DB");  

session_start();
	 $ID2 = $_SESSION['ID'];

if(isset($_POST["signup1"])){  
$year=$_POST['year'];
$div=$_POST['division'];
$contact=$_POST['contact'];

$query= "update teacher set Department = '$year', Designation = '$div',contactNo='$contact' where ID = '$ID2'";
 if(mysqli_query($con,$query))
 {
	 header('location: http://localhost/abcd/dash/modi/dash.php');
 }
}
  

    
?>