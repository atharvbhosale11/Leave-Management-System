<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo3') or die("cannot select DB");  
session_start();
	 $ID2 = $_SESSION['ID'];
if(isset($_POST["signup"])){  
$fname=$_POST['date1'];
$lname=$_POST['date2'];
$design=$_POST['hint'];
$id=$_POST['dol'];
$status='Pending';


$query2="Select ID from admin where ID='$ID2' and Action='Pending' ";
$result= $con->query($query2);
if($result->num_rows == 0)
{
//$now=now();
//date_default_timezone_set("America/New_York");
//echo "The time is " . date("h:i:sa");


$query= "INSERT INTO teacherwhichapply (FromDate,ToDate,LeaveType,Description,ID,Status,PostingDate)
VALUES ('$fname', '$lname', '$design', '$id','$ID2','$status',now())";


 if($con->query($query))
 {
	header('location: http://localhost/abcd/dash/modi/dash.php');
 }
 
 $query1= "INSERT INTO Admin (ID,Action,postingdate) 
select ID,Status,PostingDate from teacherwhichapply where ID='$ID2' and Description='$id'";




 if($con->query($query1))
 {
	 header('location: http://localhost/abcd/dash/modi/dash.php');
 }
 
}
else
{
	$message = "You have already applied for the leave. Wait for the response";
	echo "<script type='text/javascript'>alert('$message'); window.history.go(-1);</script>";
	
	
}
 
}



  

    
?>