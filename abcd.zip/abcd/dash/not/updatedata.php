

<!doctype html>
<html>
<head>
<title>Update </title>

   <style >
    * {box-sizing: border-box;
	}


.word-container {
  width: 500px;
  height: 50px;
  margin: 80px auto auto;
  
}
.word-container h1 {
  margin: 0;
  text-align: center;
  color: #ab0a0a;
  
}
.register-container {
  width: 600px;
  margin: 20px auto auto;
  border: 1px solid #000;
  padding: 20px;
  background-color:white;
}


.name label:first-child {
  margin-right: 20px;
  
}
.name label {
  width: calc(100% / 2 - 10px);
  float: left;
}
input, [type="submit"] {
  padding: 8px;
  margin-bottom: 20px;
  width: 100%;
  
}
[type="submit"] {
  border: 1px solid #000000;
  color: #ffffff;
  background-color: #ab0a0a;
  margin: 0;
}
[type="submit"]:hover {
  background-color: red;
}
    </style>
		<script>

  function checkPassword(str)
  {
    var re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
    return re.test(str);
  }

  function checkForm(form)
  {
    if(form.fname.value == "" || form.lname.value == "") {
      alert("Error: User name cannot be blank!");
      form.fname.focus();
      return false;
    }
	
	var re = /^[A-Za-z]+$/;
      if(!re.test(form.fname.value))
      {
      alert('First Name must contain only characters');
      return false;
      }
	 var re = /^[A-Za-z]+$/;
      if(!re.test(form.lname.value))
      {
      alert('Last Name must contain only characters');
      return false;
      } 
   /* re = /^\w+$/;
    if(!re.test(form.fname.value)) {
      alert("Error: Firstname must contain only letters, numbers and underscores!");
      form.fname.focus();
      return false;
    }
	*/
    if(form.pwd.value == "") {
	alert("Password fill is blank");
        form.pwd.focus();
        return false;
}
if(form.userid.value == "") {
	alert("ID fill is blank");
        form.pwd.focus();
        return false;
}
if(form.pwd1.value == "") {
	alert("Confirm Password fill is blank");
        form.pwd.focus();
        return false;
}

if(form.pwd.value != form.pwd1.value) {
	alert("Password do not match");
        form.pwd.focus();
        return false;
}

      if(!checkPassword(form.pwd.value)) {
        alert("Error: Password of type:at least one number, one lowercase and one uppercase letter and atleast six letter");
        form.pwd.focus();
        return false;
      }
     
    return true;
  }

</script>
</head>

<body style="background-color: #cccccc;">
<p style="font-size:50px;">Leave Management System</p>
   <div class="word-container">
  <h1>Update account</h1>
</div>
<div  class="register-container">
  <form action=""  onsubmit="return checkForm(this)" method="POST">
    <div class="name">
      <label>
        <input type="text" placeholder="Enter First Name" name="fname">
      </label>
      <label>
        <input type="text" placeholder="Enter Last Name" name="lname">
      </label>
    </div>
      <label>
        <input type="text" placeholder="Enter UserID" name="userid">
      </label>
	  
	  <label>
        <input list="browsers" placeholder="Choose Year" name="year">
         <datalist id="browsers">
    <option value="FE">
    <option value="SE">
    <option value="TE">
    <option value="BE">
    
  </datalist>
      </label>
      	<label>
        <input list="browsers" placeholder="Choose Division" name="division">
         <datalist id="browsers">
    <option value="I">
    <option value="II">
    <option value="III">
    <option value="IV">
    
  </datalist>
      </label>
	  <label>
        <input type="text" placeholder="Enter the contact number" name="contact">
      </label>
      
	   <div class="abc">
	  <input type="reset" class="btn btn-secondary" value="Reset" title="Reset">
       <button type="submit" name="signup" value="signup"><b>Save Changes<b></button>
	  </div>
	  
     
  </form>
</div>
<?php  

$con=mysqli_connect('localhost','root','') or die(mysqli_error());  
mysqli_select_db($con,'demo') or die("cannot select DB");  

if(isset($_POST["signup"])){  
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$design=$_POST['year'];
$id=$_POST['userid'];
$pass=$_POST['division'];
$cpass=$_POST['contact'];

$query= "update register set Dseignation= '$design', password= '$pass',confirmpassword='$cpass',ID='$id' where Firstname = '$fname'";
 if(mysqli_query($con,$query))
 {
	 echo "<h3>successfully changed</h3>";
 }
}
  

    
?>

</body>
</html>


