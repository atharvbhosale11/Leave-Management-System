<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<style>
.login-page {
  width: 360px;
  padding: 8% 0 0;
  margin: auto;
}
.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 360px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "Roboto", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background: #4CAF50;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
}



</style>
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="footer, address, phone, icons" />

	<title>Footer With Address And Phones</title>

	<link rel="stylesheet" href="css/demo.css">
	<link rel="stylesheet" href="css/footer-distributed-with-address-and-phones.css">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
</head>
<body>
<p style="font-size:50px;">Leave Management System</p>
	<img src="PICT-Pune.jpg" style='position:fixed;top:0px;left:0px;width:100%;height:100%;z-index:-1;' > 
<div class="login-page">
 <h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LOG-IN</h1>
  <div class="form">
    
    <form class="login-form" method="POST">
     <input id="username" type = "text" name="username" placeholder="UserID" required ng-model="uname"><br>
										
       <input id="password" type = "password" name="password" placeholder="password" required ng-model="pass"><br>
										
<button type="submit" value="Login" name="submit" >Login</button>
  <p>   <a href="6.html">Forgot Password?</a>&nbsp;Or&nbsp;<a href="3.html">New User?</a> </p>
    </form>
  </div>
</div>

<?php  
if(isset($_POST["submit"])){  
  
if(!empty($_POST['username']) && !empty($_POST['password'])) {  
    $user=$_POST['username'];  
    $pass=$_POST['password'];  
  
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'demo') or die("cannot select DB");  
  
    $query=mysqli_query("SELECT * FROM register WHERE id='".$_POST['user']."' AND password='".md5($_POST['pass'])."'");  
    $numrows=mysqli_num_rows($query);  
    if($numrows!=0)  
    {  
    while($row=mysqli_fetch_assoc($query))  
    {  
    $dbusername=$row['id'];  
    $dbpassword=$row['password'];  
    }  
  
    if($username == $dbusername && $password == $dbpassword)  
    {  
    session_start();  
    $_SESSION['sess_user']=$username;  
  
    /* Redirect browser */  
    header("Location: member.php");  
    }  
    } else {  
    echo "Invalid username or password!";  
    }  
  
} else {  
    echo "All fields are required!";  
}  
}  
?>




<footer class="footer-distributed">

			<div class="footer-left">
                <figure>
				<img src="Pict_logo.png" style='height:100px;'>
               </figure>
				<p class="footer-links">
					
					
					<a href="#">About</a>
					·
					<a href="#">Faq</a>
					·
					<a href="#">Contact</a>
				</p>
				<h3><a href="7.html">Sitemap</a></h3>

				
			</div>

			<div class="footer-center">

				<div>
				
					<i class="fa fa-map-marker"></i>
					<details>
				
  <p><span>Survey No. 27, Near Trimurti Chowk, Dhankawadi, Pune, Maharashtra 411043</span> Pune, India</p>
</details>
				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+91 24371101</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:www.pict.edu">principal@pict.edu</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>Working Hours</span>
					Working days:Monday to Friday<br>
                    Working Time:<time>10:00am</time> to <time>5:00pm</time>                 

				</p>

			

			</div>

		</footer>

</body>
</html>
